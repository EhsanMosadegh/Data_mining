from sklearn import linear_model
#from sklearn.linear_model import Perceptron

print('hello Ehsan')

# approach 1: remove all rows with nan
# X = 
# y =
class_obj = linear_model.Perceptron()